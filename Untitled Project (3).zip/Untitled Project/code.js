var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["d1bad5a5-817c-4000-bd0f-6f0bc327db42"],"propsByKey":{"d1bad5a5-817c-4000-bd0f-6f0bc327db42":{"name":"niño","categories":["people"],"frameCount":1,"frameSize":{"x":125,"y":398},"looping":true,"frameDelay":2,"jsonLastModified":"2021-01-15 21:44:40 UTC","pngLastModified":"2021-01-15 21:44:41 UTC","version":"to.BxxB_nG2Yh2OClpPzC6VZkmT1m7sQ","sourceUrl":"assets/api/v1/animation-library/gamelab/to.BxxB_nG2Yh2OClpPzC6VZkmT1m7sQ/category_people/blue_shirt_ball.png","sourceSize":{"x":125,"y":398},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/api/v1/animation-library/gamelab/to.BxxB_nG2Yh2OClpPzC6VZkmT1m7sQ/category_people/blue_shirt_ball.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


background("green");

drawnet();
function drawnet()
{  
  for(var num=0;num<400;num=num+20)
  {
    line(200,num,200,num+10);
  }
}
var boy = createSprite(200, 200);
boy.setAnimation("niño");
boy.scale=0.5;

drawSprites();

if (keyDown("space")) {
  boy.velocityX=2;
  
}

   


// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
